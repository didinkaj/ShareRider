<?php $__env->startSection('styles'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('assets/examples/css/tables/datatable.minfd53.css?v4.0.1')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="page-content ">
	<div class="panel">
		<div class="panel-heading">
			<h3 class="panel-title">Ride History</h3>
		</div>
		<div class="panel-body">
			<div class="row row-lg">

				<div class="card-body">
					<div class="row"><div class="col-sm-12"><table class="table table-hover dataTable table-striped w-full dtr-inline" data-plugin="dataTable" id="DataTables_Table_0" role="grid" aria-describedby="DataTables_Table_0_info" style="width: 1102px;">
            <thead>
              <tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 186px;" aria-sort="ascending" aria-label="Origin: activate to sort column descending">Origin</th>
              	<th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 200px;" aria-label="Destination: activate to sort column ascending">Destination</th>
              	<th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 104px;" aria-label="Capacity: activate to sort column ascending">Capacity</th>
              	<th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 161px;" aria-label="Driver Name: activate to sort column ascending">Driver Name</th>
              	<th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 106px;" aria-label="Driver ID: activate to sort column ascending">Driver ID</th>
              	<th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 117px;" aria-label="Driver Email: activate to sort column ascending">Driver Email</th>
              	</tr>
            </thead>
            
             <?php $__currentLoopData = $allhisto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ridehistory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr role="row" class="odd">
                <td class="sorting_1" tabindex="0"><?php echo e($ridehistory->origin); ?></td>
                <td><?php echo e($ridehistory->destination); ?></td>
                <td><?php echo e($ridehistory-> space_available); ?></td>
                <td style=""><?php echo e($ridehistory->driver_name); ?></td>
                <td style=""><?php echo e($ridehistory->driver_id); ?></td>
                <td style=""><?php echo e($ridehistory->driver_email); ?></td>
              </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            
            <tfoot>
              <tr>
              	<th rowspan="1" colspan="1">Origin</th>
              	<th rowspan="1" colspan="1">Destination</th>
              	<th rowspan="1" colspan="1">Capacity</th>
              	<th rowspan="1" colspan="1" style="">Driver Name</th>
              	<th rowspan="1" colspan="1" style="">Driver ID</th>
              	<th rowspan="1" colspan="1" style="">Driver Email</th>
              	</tr>
            </tfoot>
            <tbody>

          
              </tbody>
          </table></div></div>
				</div>
			</div>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
 <script src="<?php echo e(asset('global/js/Plugin/datatables.minfd53.js?v4.0.1')); ?>"></script>
 <script src="<?php echo e(asset('assets/examples/js/tables/datatable.minfd53.js?v4.0.1')); ?>"></script>
 <script src="<?php echo e(asset('assets/examples/js/uikit/icon.minfd53.js?v4.0.1')); ?>"></script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>