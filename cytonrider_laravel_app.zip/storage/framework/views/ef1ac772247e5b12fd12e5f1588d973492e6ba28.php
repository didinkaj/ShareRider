<div class="site-menubar site-menubar-light">
	<div class="site-menubar-body">
		<div>
			<div>
				<ul class="site-menu" data-plugin="menu">
					<li class="site-menu-item <?php echo e(request()->is('book/ride/*') ? 'active' : ''); ?>  <?php echo e(request()->is('home') ? 'active' : ''); ?> <?php echo e(request()->is('editride/*') ? 'active' : ''); ?> <?php echo e(request()->is('edit/ride/*') ? 'active' : ''); ?>">
						<a href="<?php echo e(route('home')); ?>"> <i class="site-menu-icon md-view-dashboard" aria-hidden="true"></i> <span class="site-menu-title">Dashboard</span> </a>
					</li>
					<li class="site-menu-item <?php echo e(request()->is('ride/history') ? 'active' : ''); ?> ">
						<a href="<?php echo e(url('ride/history')); ?>"> <i class="site-menu-icon fa-calendar-check-o" aria-hidden="true"></i> <span class="site-menu-title">Rides History</span> </a>
					</li>
					<li class="site-menu-item <?php echo e(request()->is('settings') ? 'active' : ''); ?> ">
						<a href="<?php echo e(route('settings')); ?>"> <i class="site-menu-icon md-settings" aria-hidden="true"></i> <span class="site-menu-title">Settings</span> </a>
					</li>
					<li class="site-menu-item">
						<a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();  document.getElementById('logout-form').submit();"> <i class="site-menu-icon md-power" aria-hidden="true"></i> <span class="site-menu-title">Logout</span> </a>
						<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
							<?php echo csrf_field(); ?>
						</form>
					</li>

				</ul>
			</div>
		</div>
	</div>
</div>