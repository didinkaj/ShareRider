<?php $__env->startSection('content'); ?>


<div class="page-content ">
	<div class="panel">
		<div class="panel-heading">
			<h3 class="panel-title">Settings</h3>
		</div>
		<div class="panel-body">
			<div class="row row-lg">

				<div class="card-body">
					Settings section
				</div>
			</div>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>