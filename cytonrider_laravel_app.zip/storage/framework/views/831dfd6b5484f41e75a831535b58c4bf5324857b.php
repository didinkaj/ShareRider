<?php $__env->startSection('title'); ?>

-Home

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="page-content">
	<div class="row">
		<?php if(Session::has('success')): ?>
		<span class="alert alert-success alert-dismissable col-md-12"> <strong><?php echo e(Session::get('success')); ?></strong>
			<button aria-hidden="true" data-dismiss="alert" class="close" type="button">
				×
			</button></span>
		<?php endif; ?>
		<?php if(Session::has('error')): ?>
		<span class="alert alert-danger alert-dismissable col-md-12"> <strong><?php echo e(Session::get('error')); ?></strong>
			<button aria-hidden="true" data-dismiss="alert" class="close" type="button">
				×
			</button></span>
		<?php endif; ?>
		<div class="col-xxl-9 col-xl-8 col-lg-12">
			<div class="card">

				<div class="card-block ">
					<h4 class="card-title  " style="color: #1e88e5;"> Available Rides <span class="float-right badge badge-round badge-warning"></span></h4>

					<hr />

					<div class="example-wrap m-lg-0">

						<br />

						<ul class="list-group list-group-dividered list-group-full" id="load-data">
							<?php $__currentLoopData = $allRides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ride): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li class="list-group-item">
								<div class="media">
									<div class="pr-20">
										<i class="icon fa-taxi" style="color: #dc3545;" aria-hidden="true"></i>

									</div>
									<div class="media-body">
										<small class="text-muted float-right"><?php echo e($ride->created_at->diffForHumans()); ?></small>
										<h5 class="mt-0 mb-5"><?php echo e($ride->driver); ?></h5>
										<div>
											<b>Origin</b> : <?php echo e(ucfirst($ride->origin)); ?> <br/>
											<b>Destination</b> : <?php echo e(ucfirst($ride->destination)); ?><br/>
											<b>Capacity</b> : <?php echo e($ride->space_available); ?><br />
											<b>Email</b> : <?php echo e(ucfirst($ride->user_email)); ?> 
										</div>
									</div>
									<div class="pl-20">
										<form autocomplete="off" method="post" action="<?php echo e(url('/book/ride/'.$ride->id)); ?>">
										<?php echo csrf_field(); ?>
										<button type="submit" class="btn btn-block btn-primary waves-effect waves-classic">
											Book
										</button>
										</form>
									</div>
								</div>
								<br />
							</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>						
						
						</ul>
						<div id="remove-row">
						<button id="btn-more" data-id="<?php echo e($ride->id); ?>" type="button" class="btn btn-block btn-primary waves-effect waves-classic">
							<i class="icon md-chevron-down mr-5" aria-hidden="true"></i>Show
							More
						</button>
						</div>

					</div>

				</div>

			</div>
		</div>

		<div class="col-xxl-3 col-xl-4 col-lg-12">
			<div class="card">
				<div class="card-block">

					<h4 class="card-title  " style="color: #;"> Add New Ride</h4>
					<hr />

					<form autocomplete="off" method="post" action="<?php echo e(url('/add/ride')); ?>">
						<?php echo csrf_field(); ?>
						<div class="form-group form-material floating" data-plugin="formMaterial">
							<input class="form-control empty" name="origin" required="required" type="text">
							<label class="floating-label">Origin</label>
						</div>
						<div class="form-group form-material floating" data-plugin="formMaterial">
							<input class="form-control empty" name="destination" required="required" type="text">
							<label class="floating-label">Destination</label>
						</div>
						<div class="form-group form-material floating" data-plugin="formMaterial">
							<input class="form-control empty" name="capacity" required="required" type="number">
							<label class="floating-label">Capacity</label>
						</div>

						<div class="float-right" >
							<button  class="btn-success btn waves-effect waves-classic" type="submit" >
								Add Ride
							</button>

						</div>

					</form>
				</div>
				<div class="card-block">
					<h4 class="card-title "> My Ride </h4>
					<hr />

					<ul class="list-group list-group-dividered list-group-full">
						<?php $__currentLoopData = $myRides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ride): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li class="list-group-item">
							<div class="media">
								<div class="pr-20">
									<i class="icon fa-taxi" style="color: #dc3545;" aria-hidden="true"></i>
								</div>
								<div class="media-body">
									<small class="text-muted float-right"><?php echo e($ride->created_at->diffForHumans()); ?></small>
									<h5 class="mt-0 mb-5"><?php echo e($ride->driver); ?></h5>
									<div>
										<b>Origin</b> : <?php echo e(ucfirst($ride->origin)); ?> <br/>
										<b>Destination</b> : <?php echo e(ucfirst($ride->destination)); ?><br/>
										<b>Capacity</b> : <?php echo e($ride->space_available); ?>

									</div>
									<div class="actions mt-10">
										<table>
											<tr>
												<td>
													<form method="POST" action="<?php echo e(url('/editride/'.$ride->id)); ?>" >
														<?php echo csrf_field(); ?>
													<button  class="btn btn-info btn-xs waves-effect waves-classic">
														<i class="icon md-edit" aria-hidden="true"></i>Edit
													</button>
													</form>
												</td>
												<td>
													<form method="POST" action="/deleteRide/<?php echo e($ride->id); ?>" >
														<?php echo csrf_field(); ?>
														<?php echo method_field('delete'); ?>

													<button type="submit" class="btn btn-default btn-xs waves-effect waves-classic">
														<i class="icon md-delete" aria-hidden="true"></i>Delete
													</button>
													</form>
												</td>
											</tr>										
										
										</table>
									</div>
								</div>

							</div>
						</li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>

				</div>

			</div>

		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('global/js/Plugin/jquery-placeholder.minfd53.js?v4.0.1')); ?>"></script>
<script src="<?php echo e(asset('global/js/Plugin/material.minfd53.js?v4.0.1')); ?>"></script>
<script>
$(document).ready(function(){
   $(document).on('click','#btn-more',function(){
       var id = $(this).data('id');
       $("#btn-more").html("Loading....");
       $.ajax({
           url : '<?php echo e(url("/homeajax")); ?>',
           method : "POST",
           data : {id:id, _token:"<?php echo e(csrf_token()); ?>"},
           dataType : "text",
           success : function (data)
           {
              if(data != '') 
              {
                  $('#remove-row').remove();
                  $('#load-data').append(data);
              }
              else
              {
                  $('#btn-more').html("No Data");
              }
           }
       });
   });  
}); 
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>