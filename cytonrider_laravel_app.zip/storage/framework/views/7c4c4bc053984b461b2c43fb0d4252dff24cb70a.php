<?php $__env->startSection('title'); ?>

<span id="extr-page-header-space"> <span class="hidden-xs-down">Need an account?</span> <a href="<?php echo e(route('register')); ?>" class="btn btn-danger">Create account</a> </span>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>      
                
                
<form method="POST" action="<?php echo e(route('password.email')); ?>" class="smart-form client-form">
<?php echo csrf_field(); ?>
<header>
	<?php echo e(__('Reset Password')); ?>

</header>
	<?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

	<fieldset>
		
		<section>
			<label class="label"><?php echo e(__('E-Mail Address')); ?></label>
			<label class="input"> <i class="icon-append fa fa-envelope"></i>
				<input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>

                <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
				<b class="tooltip tooltip-top-right"><i class="fa fa-envelope txt-color-teal"></i> Please enter email address for password reset</b></label>
		</section>
		<!-- <section>
			<span class="timeline-seperator text-center text-primary"> <span class="font-sm">OR</span> 
		</section>
		<section>
			<label class="label">Your Username</label>
			<label class="input"> <i class="icon-append fa fa-user"></i>
				<input type="text" name="username">
				<b class="tooltip tooltip-top-right"><i class="fa fa-user txt-color-teal"></i> Enter your username</b> </label>
			<div class="note">
				<a href="login.html">I remembered my password!</a>
			</div>
		</section> -->

	</fieldset>
	<footer>
		<button type="submit" class="btn btn-primary">
            <?php echo e(__('Send Password Reset Link')); ?>

        </button>
	</footer>
</form>
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.account', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>