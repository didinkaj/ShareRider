<?php $__env->startSection('title'); ?>

<span id="extr-page-header-space"> <span class="hidden-xs-down">Need an account?</span> <a href="<?php echo e(route('register')); ?>" class="btn btn-danger">Create account</a> </span>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('login')); ?>" id="login-form" class="smart-form client-form">
	<?php echo csrf_field(); ?>
	<header>
		<?php echo e(__('Login')); ?>

	</header>

	<fieldset>

		<section>
			<label class="label"><?php echo e(__('E-Mail Address')); ?></label>
			<label class="input"> <i class="icon-append fa fa-user"></i>
				 <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
				<b class="tooltip tooltip-top-right"><i class="fa fa-user txt-color-teal"></i> Please enter email address/username</b></label>
		</section>

		<section>
			<label class="label"><?php echo e(__('Password')); ?></label>
			<label class="input"> <i class="icon-append fa fa-lock"></i>
				<input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
				<b class="tooltip tooltip-top-right"><i class="fa fa-lock txt-color-teal"></i> Enter your password</b> </label>
			<div class="note">
				<a href="<?php echo e(route('password.request')); ?>"><?php echo e(__('Forgot Your Password?')); ?></a>
			</div>
		</section>

		<section>
			<label class="checkbox">
				<input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> 
				<i></i><?php echo e(__('Remember Me')); ?></label>
		</section>
	</fieldset>
	<footer>
		<button type="submit" class="btn btn-primary">
			 <?php echo e(__('Login')); ?>

		</button>
	</footer>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.account', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>