<footer class="site-footer">
	<div class="site-footer-legal">
		© 2018 <a href="#">Rider</a>
	</div>
	<div class="site-footer-right">
		Designed <i class="red-600 icon md-favorite"></i> by <a href="#">Didinya Johnson</a>
	</div>
</footer>